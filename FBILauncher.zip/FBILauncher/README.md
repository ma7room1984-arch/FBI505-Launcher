# FBI Launcher (v0.1: foundation)

Native Android launcher: Kotlin + Jetpack Compose, minSdk 26, targetSdk 35.

## Build
1. Open this folder in Android Studio (Koala or newer, JDK 17). Let Gradle sync
   (if asked to create the Gradle wrapper, accept; Gradle 8.9 is configured).
2. Run on a device/emulator (`app` configuration), or Build > Build APK(s).
3. Press Home, choose **FBI Launcher**, and tap "Always". Or use the in-app "Set" button.

> This code was written without access to an Android SDK, so it has NOT been compiled or run yet.
> Expect to fix a few small compile errors on first sync, and please report them.

## Architecture
```
FbiApp                 process singletons (no DI framework, no background work)
data/AppRepository     LauncherApps API: app list, work profiles, package events, byte-bounded icon LRU cache
data/SettingsStore     typed settings as StateFlow (SharedPreferences)
data/HomeStore         pages/dock/widget layout as StateFlow (JSON in SharedPreferences)
widgets/WidgetController   real AppWidgetHost: allocate, bind (with system consent), configure, delete
LauncherViewModel      UI state + all layout/settings mutations
MainActivity           HOME intent filter, role request, widget bind/configure results
ui/                    HomeScreen (pager + dock), AppDrawer, SettingsScreen, Components, Theme
```

## Implemented (v0.1)
- HOME + LAUNCHER intent filters; default-launcher request via RoleManager (API 29+) / Settings fallback
- Detects all launchable apps (incl. work profile) live via LauncherApps callbacks; no QUERY_ALL_PACKAGES
- Launch, app info, uninstall, hide/unhide, add to home/dock, remove
- Real App Widgets: picker of all installed providers, bind + config flow, remove, multiple pages
- Drawer: search (Enter launches top hit), sort by name/install date, grid columns, opacity, animation duration
- Settings: theme mode, accent, icon size, labels, hidden apps, wallpaper picker, reset
- Performance: lazy icon decoding off-main-thread, 8 MB LRU, debounced refresh, widget host listens only while visible

## Not built yet (planned, in this order)
1. Free-form home grid (drag, drop, resize widgets, long-press to move). Home is currently a flow grid, and
   widgets are full-width at their provider's minimum height.
2. Icon packs (ADW/Nova `appfilter.xml` standard), per-app icon override, shapes, shadows, custom PNG/JPG/WebP.
3. Clock widget editor (own AppWidgetProvider + editor; digital/analog, fonts, import).
4. Theme manager: JSON export/import of settings, backups, multiple home configurations, undo/redo.
5. Per-element animations (open/close, folders, icons) with easing curves. Only drawer duration is customizable now.
6. Folders and custom drawer categories.

## Android limitations (not workarounds)
- Importing themes/icon packs "from other launchers" is only possible where a format is documented. Icon packs
  (appfilter.xml) are a de-facto standard and feasible; Nova/Smart Launcher *backup files* are proprietary and
  can't be reliably imported.
- Third-party apps' own open/close transition animations are controlled by the system and the target app. A launcher
  can only customize its own transitions plus the launch animation options passed to startActivity.
- Widget background/border/transparency can only be changed for widgets that support it (Android 12+ rounded
  corners via the widget). A launcher can clip or frame the host view but can't restyle a widget's internals.
- Silent widget binding needs the signature-level BIND_APPWIDGET permission; normal launchers get the system consent
  dialog on first bind of a provider, which is implemented.
- Android 13+ may require users to allow "restricted settings" for sideloaded APKs in some flows.
