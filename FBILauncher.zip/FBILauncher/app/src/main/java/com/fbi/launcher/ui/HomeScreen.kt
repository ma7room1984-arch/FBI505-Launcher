@file:OptIn(ExperimentalFoundationApi::class)

package com.fbi.launcher.ui

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.fbi.launcher.LauncherViewModel
import com.fbi.launcher.Screen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(vm: LauncherViewModel, host: LauncherHost) {
    val home by vm.home.collectAsState()
    val settings by vm.settings.collectAsState()
    val appMap by vm.appMap.collectAsState()
    val pagerState = rememberPagerState { home.pages.size }
    val scope = rememberCoroutineScope()
    var showMenu by remember { mutableStateOf(false) }
    var showWidgetPicker by remember { mutableStateOf(false) }

    LaunchedEffect(vm.homeResetTick) {
        if (vm.homeResetTick > 0) pagerState.animateScrollToPage(0)
    }

    // On the home screen "back" must never leave the launcher; it returns to page 1.
    BackHandler {
        if (vm.editMode) vm.editMode = false
        else if (pagerState.currentPage != 0) scope.launch { pagerState.animateScrollToPage(0) }
    }

    val iconSize = settings.iconSizeDp.dp

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { showMenu = true }) }
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            if (!host.isDefaultHome) DefaultLauncherBanner(host)

            HorizontalPager(pagerState, Modifier.weight(1f).fillMaxWidth()) { page ->
                val items = home.pages.getOrNull(page).orEmpty()
                LazyVerticalGrid(
                    columns = GridCells.Fixed(settings.columns),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(
                        items,
                        key = { it },
                        span = { if (it.startsWith("widget:")) GridItemSpan(maxLineSpan) else GridItemSpan(1) },
                    ) { item ->
                        if (item.startsWith("widget:")) {
                            val id = item.removePrefix("widget:").toIntOrNull()
                            if (id != null) WidgetCell(id, host, vm.editMode) { vm.removeFromHome(page, item) }
                        } else {
                            val app = appMap[item.removePrefix("app:")]
                            if (app != null) AppCell(
                                app, host.repo, iconSize, settings.showLabels, Color.White, textShadow = true,
                                onClick = { host.launch(app) },
                                actions = listOf(
                                    MenuAction("App info") { host.showAppInfo(app) },
                                    MenuAction("Uninstall") { host.uninstall(app) },
                                    MenuAction("Remove from home") { vm.removeFromHome(page, item) },
                                ),
                            )
                        }
                    }
                }
            }

            if (home.pages.size > 1) PageDots(home.pages.size, pagerState.currentPage)

            Dock(vm, host, home.dock, appMap, iconSize)
        }

        AnimatedVisibility(
            visible = vm.drawerOpen,
            enter = slideInVertically(tween(settings.animationMs)) { it / 2 } + fadeIn(tween(settings.animationMs)),
            exit = slideOutVertically(tween(settings.animationMs)) { it / 2 } + fadeOut(tween(settings.animationMs)),
        ) {
            AppDrawer(vm, host, pagerState.currentPage) { vm.drawerOpen = false }
        }
    }

    if (showMenu) {
        val page = pagerState.currentPage
        AlertDialog(
            onDismissRequest = { showMenu = false },
            confirmButton = {},
            title = { Text("Home") },
            text = {
                Column {
                    MenuRow("Add widget") { showMenu = false; showWidgetPicker = true }
                    MenuRow(if (vm.editMode) "Done editing widgets" else "Edit widgets") { showMenu = false; vm.editMode = !vm.editMode }
                    MenuRow("Add page") {
                        showMenu = false; vm.addPage()
                        scope.launch { pagerState.animateScrollToPage(home.pages.size) }
                    }
                    if (home.pages.size > 1) MenuRow("Remove this page") { showMenu = false; vm.removePage(page) }
                    MenuRow("Wallpaper") { showMenu = false; host.openWallpaperPicker() }
                    MenuRow("Launcher settings") { showMenu = false; vm.screen = Screen.SETTINGS }
                }
            },
        )
    }

    if (showWidgetPicker) {
        val page = pagerState.currentPage
        WidgetPickerDialog(host, onDismiss = { showWidgetPicker = false }) { provider ->
            host.beginAddWidget(provider, page)
        }
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
    )
}

@Composable
private fun DefaultLauncherBanner(host: LauncherHost) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Make FBI Launcher your home app", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = host::requestDefaultHome) { Text("Set") }
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.45f))
            )
        }
    }
}

@Composable
private fun Dock(
    vm: LauncherViewModel,
    host: LauncherHost,
    dock: List<String>,
    appMap: Map<String, com.fbi.launcher.data.AppInfo>,
    iconSize: androidx.compose.ui.unit.Dp,
) {
    var drag by remember { mutableStateOf(0f) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.35f))
            .padding(vertical = 6.dp)
            // Swipe up on the dock opens the drawer (kept off the page area so it never fights grid scrolling).
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -60f) vm.drawerOpen = true },
                    onVerticalDrag = { _, amount -> drag += amount },
                )
            },
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val apps = dock.mapNotNull { appMap[it] }
        apps.forEachIndexed { index, app ->
            if (index == apps.size / 2) DrawerButton(iconSize) { vm.drawerOpen = true }
            AppCell(
                app, host.repo, iconSize, showLabel = false, labelColor = Color.White, textShadow = false,
                onClick = { host.launch(app) },
                actions = listOf(
                    MenuAction("App info") { host.showAppInfo(app) },
                    MenuAction("Remove from dock") { vm.removeFromDock(app.key) },
                ),
                modifier = Modifier.weight(1f),
            )
        }
        if (apps.isEmpty()) DrawerButton(iconSize) { vm.drawerOpen = true }
    }
}

@Composable
private fun DrawerButton(iconSize: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(iconSize)) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Open app drawer", tint = Color.White, modifier = Modifier.size(32.dp))
    }
}

/** Hosts a real AppWidgetHostView supplied by the widget's own app. */
@Composable
private fun WidgetCell(id: Int, host: LauncherHost, editMode: Boolean, onRemove: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val info = remember(id) { host.widgets.info(id) }
    if (info == null) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Widget unavailable (provider removed)", color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = onRemove) { Text("Remove") }
        }
        return
    }
    val heightDp = with(density) { info.minHeight.toDp() }.coerceAtLeast(48.dp)
    val minWDp = (info.minWidth / density.density).toInt()
    val minHDp = (info.minHeight / density.density).toInt()
    Box(Modifier.fillMaxWidth().padding(8.dp).height(heightDp)) {
        AndroidView(
            factory = { host.widgets.host.createView(ctx, id, info) },
            modifier = Modifier.fillMaxSize(),
            update = { it.updateAppWidgetSize(Bundle(), minWDp, minHDp, minWDp, minHDp) },
        )
        if (editMode) {
            IconButton(
                onClick = onRemove,
                modifier = Modifier.align(Alignment.TopEnd).size(32.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.7f)),
            ) { Icon(Icons.Default.Close, "Remove widget", tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
    }
}
