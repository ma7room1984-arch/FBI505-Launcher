package com.fbi.launcher.widgets

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Thin wrapper over the real Android [AppWidgetHost]. Widgets are genuine RemoteViews
 * rendered by their owning apps, not simulated.
 */
class WidgetController(private val context: Context) {
    val host = AppWidgetHost(context, HOST_ID)
    private val manager: AppWidgetManager = AppWidgetManager.getInstance(context)

    fun providers(): List<AppWidgetProviderInfo> =
        manager.installedProviders.sortedBy { it.loadLabel(context.packageManager).lowercase() }

    fun info(id: Int): AppWidgetProviderInfo? = manager.getAppWidgetInfo(id)

    fun allocateId(): Int = host.allocateAppWidgetId()
    fun delete(id: Int) = runCatching { host.deleteAppWidgetId(id) }

    /** True when bound silently; false means the user must approve via [bindIntent]. */
    fun tryBind(id: Int, provider: ComponentName): Boolean =
        manager.bindAppWidgetIdIfAllowed(id, provider)

    fun bindIntent(id: Int, provider: ComponentName): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider)

    // Listening only while the launcher is visible: no work in the background.
    fun startListening() { runCatching { host.startListening() } }
    fun stopListening() { runCatching { host.stopListening() } }

    companion object { private const val HOST_ID = 0x4642 }
}
