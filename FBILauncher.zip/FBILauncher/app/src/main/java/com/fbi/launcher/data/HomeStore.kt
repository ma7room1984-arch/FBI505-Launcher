package com.fbi.launcher.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Home layout. Page items are strings: "app:<AppInfo.key>" or "widget:<appWidgetId>".
 * The dock holds plain AppInfo keys.
 */
data class HomeState(
    val pages: List<List<String>> = listOf(emptyList()),
    val dock: List<String> = emptyList(),
    val seeded: Boolean = false,
)

class HomeStore(context: Context) {
    private val prefs = context.getSharedPreferences("fbi_home", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    fun update(transform: (HomeState) -> HomeState) {
        val next = transform(_state.value)
        if (next == _state.value) return
        _state.value = next
        prefs.edit().putString("home", toJson(next)).apply()
    }

    private fun read(): HomeState {
        val raw = prefs.getString("home", null) ?: return HomeState()
        return runCatching {
            val o = JSONObject(raw)
            val pages = o.getJSONArray("pages").let { arr ->
                List(arr.length()) { i -> arr.getJSONArray(i).toStringList() }
            }.ifEmpty { listOf(emptyList()) }
            HomeState(pages, o.getJSONArray("dock").toStringList(), o.optBoolean("seeded", false))
        }.getOrDefault(HomeState())
    }

    private fun toJson(s: HomeState): String = JSONObject()
        .put("pages", JSONArray(s.pages.map { JSONArray(it) }))
        .put("dock", JSONArray(s.dock))
        .put("seeded", s.seeded)
        .toString()

    private fun JSONArray.toStringList() = List(length()) { getString(it) }
}
