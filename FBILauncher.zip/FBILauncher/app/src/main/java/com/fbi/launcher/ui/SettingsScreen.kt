@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.fbi.launcher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.fbi.launcher.LauncherViewModel
import com.fbi.launcher.Screen
import com.fbi.launcher.data.SortMode
import com.fbi.launcher.data.ThemeMode
import kotlin.math.roundToInt

private val ACCENTS = listOf(0xFF3D7BFF, 0xFFE53935, 0xFF43A047, 0xFFFB8C00, 0xFF8E24AA, 0xFF00ACC1)

@Composable
fun SettingsScreen(vm: LauncherViewModel, host: LauncherHost) {
    val s by vm.settings.collectAsState()
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Launcher settings", style = MaterialTheme.typography.titleLarge)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Section("Default launcher")
            Text(
                if (host.isDefaultHome) "FBI Launcher is your home app." else "FBI Launcher is not your home app yet.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (!host.isDefaultHome) Button(onClick = host::requestDefaultHome, modifier = Modifier.padding(top = 8.dp)) { Text("Set as default") }

            Section("Appearance")
            ChipRow(ThemeMode.entries, s.themeMode, { it.name.lowercase().replaceFirstChar(Char::uppercase) }) { m ->
                vm.updateSettings { it.copy(themeMode = m) }
            }
            Text("Accent color", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ACCENTS.forEach { c ->
                    Column(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(if (s.accent == c) 3.dp else 0.dp, MaterialTheme.colorScheme.onBackground, CircleShape)
                            .clickable { vm.updateSettings { it.copy(accent = c) } }
                    ) {}
                }
            }
            OutlinedButton(onClick = host::openWallpaperPicker, modifier = Modifier.padding(top = 12.dp)) { Text("Change wallpaper") }

            Section("Home & grid")
            SliderRow("Columns: ${s.columns}", s.columns.toFloat(), 3f..6f, 2) { v -> vm.updateSettings { it.copy(columns = v.roundToInt()) } }
            SliderRow("Icon size: ${s.iconSizeDp} dp", s.iconSizeDp.toFloat(), 40f..72f, 7) { v -> vm.updateSettings { it.copy(iconSizeDp = v.roundToInt()) } }
            SwitchRow("Show app labels", s.showLabels) { b -> vm.updateSettings { it.copy(showLabels = b) } }
            OutlinedButton(onClick = vm::resetHome, modifier = Modifier.padding(top = 8.dp)) { Text("Reset home layout") }

            Section("App drawer")
            ChipRow(SortMode.entries, s.sortMode, { if (it == SortMode.NAME) "Name" else "Install date" }) { m ->
                vm.updateSettings { it.copy(sortMode = m) }
            }
            SliderRow("Background opacity: ${(s.drawerAlpha * 100).roundToInt()}%", s.drawerAlpha, 0.3f..1f, 0) { v -> vm.updateSettings { it.copy(drawerAlpha = v) } }
            OutlinedButton(onClick = { vm.screen = Screen.HIDDEN_APPS }, modifier = Modifier.padding(top = 8.dp)) {
                Text("Hidden apps (${s.hidden.size})")
            }

            Section("Animation")
            SliderRow(
                if (s.animationMs == 0) "Drawer animation: off" else "Drawer animation: ${s.animationMs} ms",
                s.animationMs.toFloat(), 0f..600f, 11,
            ) { v -> vm.updateSettings { it.copy(animationMs = ((v / 50f).roundToInt() * 50)) } }
        }
    }
}

@Composable
fun HiddenAppsScreen(vm: LauncherViewModel, host: LauncherHost) {
    val apps by vm.allApps.collectAsState()
    val s by vm.settings.collectAsState()
    val sorted = androidx.compose.runtime.remember(apps) { apps.sortedBy { it.label.lowercase() } }
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.SETTINGS }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Hidden apps", style = MaterialTheme.typography.titleLarge)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(sorted, key = { it.key }) { app ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(app, host.repo, 40.dp)
                    Text(app.label, Modifier.weight(1f).padding(horizontal = 16.dp), maxLines = 1)
                    Switch(checked = app.key in s.hidden, onCheckedChange = { vm.setHidden(app.key, it) })
                }
            }
        }
    }
}

@Composable private fun Section(title: String) {
    Text(title, Modifier.padding(top = 24.dp, bottom = 8.dp), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
}

@Composable private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodyMedium)
    Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
}

@Composable private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable private fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) }) }
    }
}
