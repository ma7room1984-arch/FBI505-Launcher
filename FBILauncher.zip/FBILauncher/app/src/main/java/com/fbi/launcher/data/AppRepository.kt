package com.fbi.launcher.data

import android.content.Context
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.os.UserManager
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Enumerates launchable apps through the official [LauncherApps] API (the same API the
 * system launcher uses). It needs no QUERY_ALL_PACKAGES permission, covers work profiles,
 * and pushes package add/remove/update events, so there is no polling and no background service.
 */
class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val userManager = context.getSystemService(UserManager::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    @Volatile private var infos: Map<String, LauncherActivityInfo> = emptyMap()

    /** Byte-bounded cache (8 MB) so memory stays flat even with hundreds of apps. */
    private val iconCache = object : LruCache<String, ImageBitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap) = value.width * value.height * 4
    }

    private var refreshJob: Job? = null

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh()
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh()
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh()
    }

    init {
        launcherApps.registerCallback(callback, Handler(Looper.getMainLooper()))
        refresh(debounceMs = 0)
    }

    /** Debounced: a burst of package events (e.g. a bulk update) triggers a single reload. */
    fun refresh(debounceMs: Long = 300) {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            delay(debounceMs)
            load()
        }
    }

    private fun load() {
        val map = LinkedHashMap<String, LauncherActivityInfo>()
        for (profile in userManager.userProfiles) {
            val serial = userManager.getSerialNumberForUser(profile)
            for (ai in launcherApps.getActivityList(null, profile)) {
                if (ai.applicationInfo.packageName == context.packageName) continue
                map["${ai.componentName.flattenToShortString()}#$serial"] = ai
            }
        }
        infos = map
        _apps.value = map.map { (key, ai) ->
            AppInfo(
                key = key,
                label = ai.label?.toString().orEmpty(),
                packageName = ai.applicationInfo.packageName,
                component = ai.componentName,
                user = ai.user,
                installTime = ai.firstInstallTime,
                updateTime = ai.lastUpdateTime,
            )
        }
    }

    fun cachedIcon(app: AppInfo): ImageBitmap? = iconCache.get(app.iconKey)

    /** Decoded off the main thread, lazily, only for icons that are actually on screen. */
    suspend fun loadIcon(app: AppInfo): ImageBitmap? {
        iconCache.get(app.iconKey)?.let { return it }
        return withContext(Dispatchers.IO) {
            val info = infos[app.key] ?: return@withContext null
            runCatching { info.getIcon(0).toBitmap(ICON_PX, ICON_PX).asImageBitmap() }
                .getOrNull()
                ?.also { iconCache.put(app.iconKey, it) }
        }
    }

    fun launch(app: AppInfo, sourceBounds: Rect? = null): Boolean = runCatching {
        launcherApps.startMainActivity(app.component, app.user, sourceBounds, null)
        true
    }.getOrDefault(false)

    fun openAppDetails(app: AppInfo): Boolean = runCatching {
        launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        true
    }.getOrDefault(false)

    private companion object {
        const val ICON_PX = 144
    }
}
