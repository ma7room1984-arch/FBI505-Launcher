package com.fbi.launcher.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class SortMode { NAME, INSTALL_DATE }

data class LauncherSettings(
    val columns: Int = 4,
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val sortMode: SortMode = SortMode.NAME,
    val animationMs: Int = 300,
    val drawerAlpha: Float = 0.92f,
    val accent: Long = 0xFF3D7BFF,
    val hidden: Set<String> = emptySet(),
)

/** SharedPreferences-backed settings exposed as a StateFlow. Writes are applied asynchronously. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("fbi_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<LauncherSettings> = _state.asStateFlow()

    fun update(transform: (LauncherSettings) -> LauncherSettings) {
        val next = transform(_state.value)
        if (next == _state.value) return
        _state.value = next
        write(next)
    }

    private fun read(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            columns = prefs.getInt("columns", d.columns),
            iconSizeDp = prefs.getInt("iconSizeDp", d.iconSizeDp),
            showLabels = prefs.getBoolean("showLabels", d.showLabels),
            themeMode = runCatching { ThemeMode.valueOf(prefs.getString("themeMode", null)!!) }.getOrDefault(d.themeMode),
            sortMode = runCatching { SortMode.valueOf(prefs.getString("sortMode", null)!!) }.getOrDefault(d.sortMode),
            animationMs = prefs.getInt("animationMs", d.animationMs),
            drawerAlpha = prefs.getFloat("drawerAlpha", d.drawerAlpha),
            accent = prefs.getLong("accent", d.accent),
            hidden = prefs.getStringSet("hidden", emptySet())?.toSet().orEmpty(),
        )
    }

    private fun write(s: LauncherSettings) {
        prefs.edit()
            .putInt("columns", s.columns)
            .putInt("iconSizeDp", s.iconSizeDp)
            .putBoolean("showLabels", s.showLabels)
            .putString("themeMode", s.themeMode.name)
            .putString("sortMode", s.sortMode.name)
            .putInt("animationMs", s.animationMs)
            .putFloat("drawerAlpha", s.drawerAlpha)
            .putLong("accent", s.accent)
            .putStringSet("hidden", s.hidden)
            .apply()
    }
}
