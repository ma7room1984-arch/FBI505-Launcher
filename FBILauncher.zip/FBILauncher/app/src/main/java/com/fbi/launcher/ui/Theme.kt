package com.fbi.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fbi.launcher.data.LauncherSettings
import com.fbi.launcher.data.ThemeMode

@Composable
fun FbiTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = Color(settings.accent)
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = accent) else lightColorScheme(primary = accent),
        content = content,
    )
}
