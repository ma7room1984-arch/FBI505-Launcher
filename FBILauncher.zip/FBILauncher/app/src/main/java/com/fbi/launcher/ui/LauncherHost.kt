package com.fbi.launcher.ui

import android.content.ComponentName
import com.fbi.launcher.data.AppInfo
import com.fbi.launcher.data.AppRepository
import com.fbi.launcher.widgets.WidgetController

/** What the UI needs from the Activity (things that require an Activity/Context). */
interface LauncherHost {
    val isDefaultHome: Boolean
    val repo: AppRepository
    val widgets: WidgetController
    fun launch(app: AppInfo)
    fun showAppInfo(app: AppInfo)
    fun uninstall(app: AppInfo)
    fun beginAddWidget(provider: ComponentName, page: Int)
    fun requestDefaultHome()
    fun openWallpaperPicker()
}
