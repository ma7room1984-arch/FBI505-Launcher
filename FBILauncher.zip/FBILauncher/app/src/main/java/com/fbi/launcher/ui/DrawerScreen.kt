package com.fbi.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.fbi.launcher.LauncherViewModel

@Composable
fun AppDrawer(vm: LauncherViewModel, host: LauncherHost, currentPage: Int, onClose: () -> Unit) {
    val apps by vm.visibleApps.collectAsState()
    val settings by vm.settings.collectAsState()
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }

    BackHandler { if (query.isNotEmpty()) query = "" else onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = settings.drawerAlpha))
            .windowInsetsPadding(WindowInsets.systemBars)
            .imePadding()
    ) {
        TextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search ${apps.size} apps") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            // Enter launches the top result: fast keyboard-driven launching.
            keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let { host.launch(it); onClose() } }),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(settings.columns),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(filtered, key = { it.key }) { app ->
                AppCell(
                    app, host.repo, settings.iconSizeDp.dp, settings.showLabels,
                    labelColor = MaterialTheme.colorScheme.onSurface, textShadow = false,
                    onClick = { host.launch(app); onClose() },
                    actions = listOf(
                        MenuAction("Add to home") { vm.addToHome(app, currentPage); onClose() },
                        MenuAction("Add to dock") { vm.addToDock(app) },
                        MenuAction("App info") { host.showAppInfo(app) },
                        MenuAction("Hide") { vm.hideApp(app.key) },
                        MenuAction("Uninstall") { host.uninstall(app) },
                    ),
                )
            }
        }
    }
}
