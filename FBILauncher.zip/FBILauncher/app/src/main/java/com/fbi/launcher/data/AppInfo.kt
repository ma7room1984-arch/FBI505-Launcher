package com.fbi.launcher.data

import android.content.ComponentName
import android.os.UserHandle

/**
 * One launchable activity. [key] is stable across refreshes and unique per
 * (component, user profile) so work-profile clones don't collide.
 */
data class AppInfo(
    val key: String,
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val installTime: Long,
    val updateTime: Long,
) {
    /** Changes when the app updates, so a changed icon invalidates the cache. */
    val iconKey: String get() = "$key@$updateTime"
}
