package com.fbi.launcher

import android.app.role.RoleManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.fbi.launcher.data.AppInfo
import com.fbi.launcher.data.AppRepository
import com.fbi.launcher.ui.FbiTheme
import com.fbi.launcher.ui.HiddenAppsScreen
import com.fbi.launcher.ui.HomeScreen
import com.fbi.launcher.ui.LauncherHost
import com.fbi.launcher.ui.SettingsScreen
import com.fbi.launcher.widgets.WidgetController

class MainActivity : ComponentActivity(), LauncherHost {

    private val vm: LauncherViewModel by viewModels()
    private val fbi get() = application as FbiApp

    override val repo: AppRepository get() = fbi.repo
    override val widgets: WidgetController get() = fbi.widgets

    private var defaultState by mutableStateOf(false)
    override val isDefaultHome: Boolean get() = defaultState

    private var pendingWidgetId = -1
    private var pendingPage = 0

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refreshDefaultState() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = SystemBarStyle.dark(Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = transparent, navigationBarStyle = transparent)

        setContent {
            val settings by vm.settings.collectAsState()
            FbiTheme(settings) {
                when (vm.screen) {
                    Screen.HOME -> HomeScreen(vm, this)
                    Screen.SETTINGS -> {
                        BackHandler { vm.screen = Screen.HOME }
                        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                            SettingsScreen(vm, this)
                        }
                    }
                    Screen.HIDDEN_APPS -> {
                        BackHandler { vm.screen = Screen.SETTINGS }
                        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                            HiddenAppsScreen(vm, this)
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgets.startListening()
    }

    override fun onStop() {
        widgets.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshDefaultState()
    }

    /** Home button pressed while we're already the foreground launcher. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            vm.drawerOpen = false
            vm.editMode = false
            vm.screen = Screen.HOME
            vm.homeResetTick++
        }
    }

    private fun refreshDefaultState() {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        defaultState = ri?.activityInfo?.packageName == packageName
    }

    // ---- LauncherHost ----
    override fun launch(app: AppInfo) {
        if (!repo.launch(app)) toast("Couldn't open ${app.label}")
    }

    override fun showAppInfo(app: AppInfo) {
        if (!repo.openAppDetails(app)) toast("Couldn't open app info")
    }

    override fun uninstall(app: AppInfo) {
        runCatching {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
        }.onFailure { toast("Couldn't start uninstall") }
    }

    override fun requestDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                return
            }
        }
        runCatching { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
            .onFailure { toast("Open Settings > Apps > Default apps > Home app") }
    }

    override fun openWallpaperPicker() {
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        }.onFailure { toast("No wallpaper picker available") }
    }

    // ---- real AppWidget bind/configure flow ----
    override fun beginAddWidget(provider: ComponentName, page: Int) {
        pendingPage = page
        val id = widgets.allocateId()
        pendingWidgetId = id
        if (widgets.tryBind(id, provider)) configureOrFinish(id)
        else @Suppress("DEPRECATION") startActivityForResult(widgets.bindIntent(id, provider), REQ_BIND)
    }

    private fun configureOrFinish(id: Int) {
        val info = widgets.info(id)
        if (info?.configure != null) {
            try {
                widgets.host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                cancelPending()
                toast("This widget couldn't be configured")
            }
        } else finishPending()
    }

    private fun finishPending() {
        if (pendingWidgetId != -1) vm.addWidget(pendingWidgetId, pendingPage)
        pendingWidgetId = -1
    }

    private fun cancelPending() {
        if (pendingWidgetId != -1) widgets.delete(pendingWidgetId)
        pendingWidgetId = -1
    }

    @Deprecated("Required by AppWidgetHost configure flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        val ok = resultCode == RESULT_OK
        when (requestCode) {
            REQ_BIND -> if (ok && pendingWidgetId != -1) configureOrFinish(pendingWidgetId) else cancelPending()
            REQ_CONFIGURE -> if (ok) finishPending() else cancelPending()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private companion object {
        const val REQ_BIND = 101
        const val REQ_CONFIGURE = 102
    }
}
