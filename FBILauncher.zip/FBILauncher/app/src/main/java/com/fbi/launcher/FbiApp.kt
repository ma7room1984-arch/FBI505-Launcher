package com.fbi.launcher

import android.app.Application
import com.fbi.launcher.data.AppRepository
import com.fbi.launcher.data.HomeStore
import com.fbi.launcher.data.SettingsStore
import com.fbi.launcher.widgets.WidgetController

/** Process-wide singletons. Kept tiny on purpose: no DI framework, no background work. */
class FbiApp : Application() {
    lateinit var repo: AppRepository; private set
    lateinit var settingsStore: SettingsStore; private set
    lateinit var homeStore: HomeStore; private set
    lateinit var widgets: WidgetController; private set

    override fun onCreate() {
        super.onCreate()
        settingsStore = SettingsStore(this)
        homeStore = HomeStore(this)
        widgets = WidgetController(this)
        repo = AppRepository(this)
    }
}
