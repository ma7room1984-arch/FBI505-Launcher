@file:OptIn(ExperimentalFoundationApi::class)

package com.fbi.launcher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.fbi.launcher.data.AppInfo
import com.fbi.launcher.data.AppRepository

class MenuAction(val label: String, val onClick: () -> Unit)

/** Icon is decoded lazily off the main thread; cached bitmaps appear synchronously. */
@Composable
fun AppIcon(app: AppInfo, repo: AppRepository, size: Dp) {
    var bmp by remember(app.iconKey) { mutableStateOf(repo.cachedIcon(app)) }
    LaunchedEffect(app.iconKey) { if (bmp == null) bmp = repo.loadIcon(app) }
    Box(Modifier.size(size)) {
        bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.size(size)) }
    }
}

@Composable
fun AppCell(
    app: AppInfo,
    repo: AppRepository,
    iconSize: Dp,
    showLabel: Boolean,
    labelColor: Color,
    textShadow: Boolean,
    onClick: () -> Unit,
    actions: List<MenuAction>,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .combinedClickable(onClick = onClick, onLongClick = { expanded = true })
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIcon(app, repo, iconSize)
            if (showLabel) {
                val base = LocalTextStyle.current.copy(fontSize = 11.sp)
                Text(
                    app.label,
                    color = labelColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = if (textShadow) base.copy(shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 2f), 4f)) else base,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            actions.forEach { a ->
                DropdownMenuItem(text = { Text(a.label) }, onClick = { expanded = false; a.onClick() })
            }
        }
    }
}

/** Lists every widget provider installed on the device (real AppWidgetProviderInfo). */
@Composable
fun WidgetPickerDialog(host: LauncherHost, onDismiss: () -> Unit, onPick: (android.content.ComponentName) -> Unit) {
    val ctx = LocalContext.current
    val providers = remember { host.widgets.providers() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add widget") },
        text = {
            if (providers.isEmpty()) Text("No widgets are installed on this device.")
            else LazyColumn {
                items(providers, key = { it.provider.flattenToString() }) { p ->
                    val label = remember(p) { p.loadLabel(ctx.packageManager) }
                    val preview = remember(p) {
                        runCatching { p.loadPreviewImage(ctx, 0)?.toBitmap(160, 160)?.asImageBitmap() }.getOrNull()
                    }
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(p.provider); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(56.dp)) {
                            preview?.let { Image(it, null, Modifier.size(56.dp)) }
                        }
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                            val d = ctx.resources.displayMetrics.density
                            Text(
                                "${(p.minWidth / d).toInt()} x ${(p.minHeight / d).toInt()} dp",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
