package com.fbi.launcher

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fbi.launcher.data.AppInfo
import com.fbi.launcher.data.SortMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, HIDDEN_APPS }

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val fbi = application as FbiApp
    private val settingsStore = fbi.settingsStore
    private val homeStore = fbi.homeStore

    val settings = settingsStore.state
    val home = homeStore.state
    val allApps = fbi.repo.apps

    var screen by mutableStateOf(Screen.HOME)
    var drawerOpen by mutableStateOf(false)
    var editMode by mutableStateOf(false)
    var homeResetTick by mutableIntStateOf(0)

    val appMap: StateFlow<Map<String, AppInfo>> = allApps
        .map { list -> list.associateBy { it.key } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** Drawer list: hidden apps removed, sorted per setting. */
    val visibleApps: StateFlow<List<AppInfo>> = combine(allApps, settings) { apps, s ->
        val shown = apps.filter { it.key !in s.hidden }
        when (s.sortMode) {
            SortMode.NAME -> shown.sortedBy { it.label.lowercase() }
            SortMode.INSTALL_DATE -> shown.sortedByDescending { it.installTime }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            val apps = allApps.first { it.isNotEmpty() }
            if (!home.value.seeded) seedDefaultDock(apps)
        }
    }

    /** Dock defaults come from real default handlers (dialer, SMS, browser, camera), never hard-coded apps. */
    private fun seedDefaultDock(apps: List<AppInfo>) {
        val pm = getApplication<Application>().packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        val dock = probes
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .distinct()
            .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg }?.key }
        homeStore.update { it.copy(dock = dock, seeded = true) }
    }

    // ---- settings ----
    fun hideApp(key: String) = settingsStore.update { it.copy(hidden = it.hidden + key) }
    fun setHidden(key: String, hidden: Boolean) =
        settingsStore.update { it.copy(hidden = if (hidden) it.hidden + key else it.hidden - key) }
    fun updateSettings(t: (com.fbi.launcher.data.LauncherSettings) -> com.fbi.launcher.data.LauncherSettings) =
        settingsStore.update(t)

    // ---- home layout ----
    fun addToHome(app: AppInfo, page: Int) = homeStore.update { s ->
        val item = "app:${app.key}"
        if (s.pages.any { item in it }) s
        else s.copy(pages = s.pages.mapIndexed { i, p -> if (i == page) p + item else p })
    }

    fun removeFromHome(page: Int, item: String) {
        if (item.startsWith("widget:")) item.removePrefix("widget:").toIntOrNull()?.let { fbi.widgets.delete(it) }
        homeStore.update { s -> s.copy(pages = s.pages.mapIndexed { i, p -> if (i == page) p - item else p }) }
    }

    fun addWidget(id: Int, page: Int) = homeStore.update { s ->
        s.copy(pages = s.pages.mapIndexed { i, p -> if (i == page) p + "widget:$id" else p })
    }

    fun addToDock(app: AppInfo) = homeStore.update { s ->
        if (app.key in s.dock || s.dock.size >= MAX_DOCK) s else s.copy(dock = s.dock + app.key)
    }

    fun removeFromDock(key: String) = homeStore.update { it.copy(dock = it.dock - key) }

    fun addPage() = homeStore.update { it.copy(pages = it.pages + listOf(emptyList())) }

    fun removePage(page: Int) = homeStore.update { s ->
        if (s.pages.size <= 1) s else {
            s.pages[page].filter { it.startsWith("widget:") }
                .forEach { w -> w.removePrefix("widget:").toIntOrNull()?.let { fbi.widgets.delete(it) } }
            s.copy(pages = s.pages.filterIndexed { i, _ -> i != page })
        }
    }

    fun resetHome() {
        home.value.pages.flatten().filter { it.startsWith("widget:") }
            .forEach { w -> w.removePrefix("widget:").toIntOrNull()?.let { fbi.widgets.delete(it) } }
        homeStore.update { it.copy(pages = listOf(emptyList()), seeded = false) }
        viewModelScope.launch { seedDefaultDock(allApps.value) }
    }

    companion object { const val MAX_DOCK = 4 }
}
